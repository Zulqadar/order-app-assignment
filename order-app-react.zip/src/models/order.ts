export interface Order {
    firstName: string;
    lastName: string;
    description: string;
    quantity: number;
}